<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> Job Search Assistance </h1>
                        
                        <p>When your job search isn't going as well as you expected, it's high time to re-think on the process and make good sense to get help from professionals who assist with it. A virtual job search assistant can help you expedite your job search and focus on the best resources to help you get hired fast. Being in recruitment industry for almost two decades we have solid references from most of the domains and we can route you through right path in your search providing all the necessary support.
                        </p>
                        
<p>                        
                        
We shall work as your Virtual Assistant (VA) to update professional CV / Cover Letter, search and apply for jobs published on newspapers, social media, companies websites, recruiters websites & other job portals on daily basis to get job interviews for you. This service will be most suitable for senior level professionals hardly get time to go through the vacancies and apply in individual websites.
</p>

<h4>The Scope of the Service:</h4>
<ul>
<li>	Preparation of Professional CV & Covering Letter</li>
<li>Searching and updating on suitable job opportunities</li>
<li>CV Uploads to Relevant Job Portals & websites</li>
<li>Job Applications through Emails</li>
<li>Applications to Jobs Announced in Social Media, Job Portals & Websites</li>
<li>Uploading profiles in relevant company websites</li>
<li>Managing your LinkedIn account content</li>
</ul>


<h4>Key Highlights</h4>
<ul>

<li>Job search assistant will be allocated to you who will be working as per your instruction on job search.</li>
<li>Reports will be sent to you on a daily basis on CVs updated and jobs applied. </li>
<li>Minimum subscription period is one month and renewable at the end of every period.</li>
 
 </ul>                       
                         
 <p> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=4" class="linkbtn "> Subscribe <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>