<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> Job Alerts </h1>
                         
                        <p>
                        Thousands of jobs are published on a daily basis in various online and print media by various companies. Going through all those job posts is hard task and will consume your time. Among the vacancies announced, our consultants will pick the jobs most suitable for your profile and update you through e mail / WhatsApp. So that you will not miss out any job published in the region. Job alerts will help the candidates to catch up as and when a good opportunity comes in which suits the candidate�s profile and be in the first list of applicants for the job.
                        </p>
                         
  
                         
                         
                         
                         
                         
 <p> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=6" class="linkbtn "> Subscribe <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>