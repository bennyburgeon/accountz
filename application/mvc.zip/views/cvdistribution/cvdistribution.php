<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> CV Distribution     </h1>
                         
                        <p>
                       We can distribute your CV to 1000s of employers who may be looking for the similar profiles. We will e mail the profile to the person in charge of recruitment with recruitment consultants. Freight Forwarding, Shipping and Distribution companies and other corporates looking for profiles in Logistics and Supply Chain Sectors. 
                        </p>
                         
  
                         
                         
                         
                         
                         
 <p> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=8" class="linkbtn "> Subscribe <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>