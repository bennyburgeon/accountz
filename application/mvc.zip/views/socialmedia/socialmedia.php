<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> Social Media Presence </h1>
                         
                        <p>
                       Have you ever gone through and deleted certain posts from your social media profiles when applying for a job? You likely should - according to research, almost 70% of recruiters check out candidates' social media profiles when assessing their suitability for a position, and with such insights readily available, it makes sense that people who are looking to invest in you as an employee would be interested to know as much as they can.  </p>
                       
                       <p>
SeekersHR assist you in building professional social media presence by assisting you in showcasing your profile updated in various social media platforms with latest trends and techniques.

                        </p>
                         
  
     <h4>Key Highlights:</h4>
     
     <ul>
     <li>Updating profiles in LinkedIn and other social media platforms   
</li>
     <li>Rewriting your profile to match to the social media requirements </li>
     <li>Video CVs and Visual CVs</li>
     </ul>                    
                         
                         
                         
                         
 <p> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=5" class="linkbtn "> Subscribe <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>