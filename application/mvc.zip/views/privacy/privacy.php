<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> Privacy Policy</h1>
                         
                         <h4> logis.ae - Privacy Policy </h4>
 <p style="text-align: justify;">
All data uploaded on WWW.LOGIS.AE / SEEKERS CONSULTANCY becomes the exclusive property of WWW.LOGIS.AE / SEEKERS CONSULTANCY and the user consents to the material being included in the searchable database of WWW.LOGIS.AE / SEEKERS CONSULTANCY or any other ancillary website maintained by WWW.LOGIS.AE / SEEKERS CONSULTANCY and offering similar services and data can be used by WWW.LOGIS.AE / SEEKERS CONSULTANCY clients for review or shortlist such as registered Recruiters or Employers.
</p>

 <p style="text-align: justify;">
All data related to references used by job applicant in registration process is at sole discretion of WWW.LOGIS.AE / SEEKERS CONSULTANCY and by uploading the data related to references jobseeker is authorizing WWW.LOGIS.AE / SEEKERS CONSULTANCY to send acknowledgement E-mail to your references for verification and also sending any other relevant information such as marketing E-mail to the reference E-mail address. WWW.LOGIS.AE / SEEKERS CONSULTANCY will respect any unsubscribe request been sent from references added to its database.
</p>
 <p style="text-align: justify;">
The User of these services does not claim any copyright or other Intellectual Property Right over the data uploaded by him/her on the website.
</p>
 <p style="text-align: justify;">

Confidentiality
</p>
 <p style="text-align: justify;">
The Receiving Party shall keep confidential and secret and not disclose to any third party the Confidential Information nor any part of it, except to any of the Receiving Party’s Associates, if required and upon prior permission in writing from the Disclosing Party. The Receiving Party agrees to take all possible precautions with regard to protecting confidential information from any third party and shall ensure that all its Associates to whom such disclosure is made will act in accordance with the terms of this Agreement as if each of them were a party to this Agreement, and if required obtain a written statement from each of its employees/associates having access to such Proprietary Information undertaking to abide by the confidentiality conditions. All Proprietary 
Information shall be kept separate and exclusive and at the usual place of business (or residence as the case may be) of the Receiving Party.
</p>

 <p style="text-align: justify;">Use of Information/Data Supplied</p>
 <p style="text-align: justify;">
The User hereby agrees and irrevocably authorizes that the Company has the right to:
Use for the company’s own purpose, any data or/and information supplied by the User in connection with this Agreement, and/or pass on such information to any other associated companies or selected third parties.
</p>

 <p style="text-align: justify;">
Retain all data or/and information supplied by the User while using the Service to remain at logis.ae for the exclusive use of the Company in accordance with service agreement with the user, notwithstanding any termination of the Agreement or suspension of the Service to the User herein. Anything contrary to the above, unless specifically put down in writing, following the termination or suspension of the Service to the User, all such data and information shall remain in the Company’s property, records and databases as the exclusive property of the Company, for all times to come.
</p>

 <p style="text-align: justify;">Credit Card Information </p>

 <p style="text-align: justify;">
SEEKERS CONSULTANCY does not store or keep credit card data in a location that is accessible via the Internet, neither has it stored any data in its database. All credit card transactions are handled by our merchant 2checkout.com and all credit card data is encrypted and used only for legitimate purpose to process the payments for our invoice against service provided. SEEKERS CONSULTANCY uses the maximum care as is possible to ensure that all or any data / information in respect of electronic transfer of money does not fall in the wrong hands and that’s the reason we have SSL certificate installed on our bankers servers to protect you against possible internet threat.
</p>

 <p style="text-align: justify;">
Seekers Consultancy shall not be liable for any loss or damage sustained by reason of any disclosure (inadvertent or otherwise) of any information concerning the user's account and / or information relating to or regarding online transactions using credit cards / debit cards and / or their verification process and particulars nor for any error, omission or inaccuracy with respect to any information so disclosed and used whether or not in pursuance of a legal process or otherwise by its merchant 2checkout.com.
</p>


 <p style="text-align: justify;">All Laws of the United Arab Emirates specifically regulating Electronic Transactions and Commerce have been complied with.</p>



                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>