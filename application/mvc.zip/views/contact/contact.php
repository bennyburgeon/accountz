	

	<!-- Content -->

    

<div class="joblisting">

      <div class="container"> 

      <div class="row">

     

          

          

 

          

    <div class="contact-bxs">

            <div class="container">

        <div class="row">

          <div class="col-sm-12 col-md-12 col-lg-6">    

              

              <div class="contact-widget">

							<h3 >Contact Us</h3>

							<ul class="xs-info-list">

								<li><i class="fa fa-home "></i>Seekers Consultancy LLC</li>

                              	<li><i class="fa fa-map-marker"></i>P.O Box 20893, Dubai, UAE</li>

								<li><i class="fa fa-phone "></i>+971 4 2693600</li>
   								<li><i class="fa fa-phone "></i>WhatsApp : +971 50 3860 610</li>
								<li><i class="fa fa-envelope "></i><a href="mailto:info@seekershr.com">info@seekershr.com</a></li>

							</ul>

                       <p><strong>Logistics / Supply Chain Candidates please forward your CV to : jobs@logis.ae</strong></p>

                       

						 

         				 <ul class="xs-info-list">

								<li><i class="fa fa-home "></i>Enarin Business Soltuions Pvt Ltd,</li>

                              	<li><i class="fa fa-map-marker"></i> Gandhi Nagar, Ernakulam, Kochi, Kerala, India Pin 682017 </li>

								<li><i class="fa fa-phone "></i> +91 484 401 6735</li>

								<li><i class="fa fa-envelope "></i><a href="mailto:jobs@seekershr.com ">kochi@logis.ae </a></li>

							</ul>



              </div>

           </div>

          

            <div class="col-sm-12 col-md-12 col-lg-6">     

                

                

                             

                 <div class="registerfrm  mapsd">

                <div class="panel-body">

                    

                    <h5>  Inquiry/Service Request</h5>

                    

                    <div class="panel panel-info">

                    

   <form action="<?php echo $this->config->base_url();?>index.php/contact/confirm" method="post" onSubmit="return candidate_contact_form();">               

                        <div class="panel-body">

  <input type="hidden" name="service_type" value="<?php echo $service_type;?>">

 <div class="form-group">

 <input type="text" name="full_name" value="" class="form-control input-sm" placeholder="Full Name" id="full_name">

      </div>

   <div class="form-group">

        <input type="text" class="form-control input-sm" name="emailid" placeholder="Email" id="emailid">

          </div>

      <div class="form-group">

        <input type="text" class="form-control input-sm" name="mobile" placeholder="Phone" id="mobile">

          </div>                         



               <div class="form-group">                

    <textarea name="comments" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Comments / Service Request"></textarea>                  

         </div>            

                    

                    

       <div class="form-group">          

           <button type="submit" id="submit_form" class="btn btn-info "><strong><i class="fa fa-paper-plane" aria-hidden="true"></i> Send Message </strong></button>      </div>               

                            

                            

   </div>

   </form>

   

 </div>

                    



                        

              

              </div>

            </div>

                

                

                

                

                

            

    

            

            </div>    

            <!-- 

            <div class="col-sm-12"> 

                <div class="mapsd" style="margin-top: 30px;">

                <div class="mapouter">                
<!-- 
                <iframe width="100%" height="500" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3608.0242123901035!2d55.326240814485764!3d25.26977093495465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f5cc6f98fb4f3%3A0x64cc52f77d6dafe2!2sSeekers%20HR%20%26%20Recruitment%20Consultants%20in%20Dubai%20UAE!5e0!3m2!1sen!2sin!4v1601722343492!5m2!1sen!2sin" frameborder="0" style="border:0;" aria-hidden="false" tabindex="0"></iframe>
-->
                

                </div>

                

                </div>   </div> 

		-->            

            

          

          </div> </div> </div>

   

                

          

          

          

          

    

</div>  </div>  </div>  

	<!-- Content -->    