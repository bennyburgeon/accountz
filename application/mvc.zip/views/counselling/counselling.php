<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> Career Counselling </h1>
                         
                        <p>
                       Seek professional advice from an experienced career counsellor in logistics and supply chain sectors in UAE to assist you in discovering your career passion. Learn to market yourself to potential employers, resolve workplace conflicts and develop a career plan. This service may be availed by job seekers and currently employed professionals. 
                        </p>
                         
  
  <h4>Our Career counsellors can help you</h4>
  
  <ul>
  
  <li>Develop a career plan</li>
 <li>Make more effective decisions</li>
 <li>Assess your best job options, through career assessments and other tools</li>
 <li>Develop job search skills, such as writing effective resumes</li>
 <li>Find work-life balance</li>
 <li>Resolve personal conflicts with bosses and co-workers</li>
 <li>Navigate job stress, career transitions and other difficult employment issues</li> 
  
  </ul>
                         
                         
 <p> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=2" class="linkbtn "> Subscribe <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>