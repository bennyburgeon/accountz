<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> CV Highlight / Featured Profile   </h1>
                         
                        <p>
                      Thousands of CVs are registered with <a href="http://www.logis.ae">www.logis.ae</a> on a daily basis. Our Clients are posting jobs and looking for suitable profiles on a daily basis. </p>
                      
                      <p>
Opting for this service will enable your CV to be highlighted among all the CVs in the search and will show on priority or most suitable list to the consultants. This will give more chances for your CV to be viewed by the client and increase the chances to be called for an interview. 

                        </p>
                         
 <p> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=7" class="linkbtn "> Subscribe <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>