<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> Webinar </h1>
                         
                         <h4>Interview Skills and Career Guidance Webinars </h4>
                         
                         <p style="text-align: justify;">
                         Our webinars are short and sharp interactive sessions which you can plan from anywhere with internet access and get a wide spectrum on interview skills tips and techniques.
                         </p>
                         
                         
                          <p style="text-align: justify;">
                         Ranging from topics from the starting stage of interview preparation to closure stage, our webinars offer ideas to make everyday life in an office or in general to succeed in your career life.
                         </p>
                         
                         
                          <p style="text-align: justify;">
                         
                         Features:
                         </p>
                         
                         <ul>
                             <li>Attend a “virtual class” from anywhere as long as you have access to the Internet and a phone</li>
                             <li>Listen to webinar facilitators via conference call while you view presentations on your screen</li>
                             <li>Access with webinar facilitators and other participants</li>
                             <li>Submit questions anytime during the webinar and participate in live polls</li>
                         </ul>
                         
  <p style="text-align: justify;"> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=9" class="linkbtn "> Sign up for an exclusive invite to our monthly webinar series <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
    
</div>   </div> </div>