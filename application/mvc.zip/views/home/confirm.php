<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> Success </h1>
                         
                         <h4> <?php 
		
		if($prstatus=='applied')
		{
		?>
             <br>Thank you for applying. If your profile is shortlisted for the role, one of our consultant will be in touch with you soon.
                            
        <?php 
		}
		?>
</h4>

                         
                         
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>