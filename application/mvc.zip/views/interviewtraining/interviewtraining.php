<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> Job Search & Interview Training </h1>
                         
<strong>                         Job search and Interview Training Session for job seekers of Logistics & Supply Chain Sectors.</strong><br>
<br>

                        <p>
                        Get your Job seeking hunt and interview worries out of you through a training session conducted by professional trainers in <strong>Logis.AE</strong>. It will help you to make your job searching process easy and successful.
                        </p>
                        
                        <p>
                        
                        Define your goals and set your direction right for your job seeking success. We support you to get your dream job! Once you subscribe the service, our representative will contact you to add you in a convenient schedule for the training session.</p>
                        
                        <h4>What you gain from the Training Session?</h4>
                        
                        <ul>
                        
<li>	Get introduced to the logistics job market where you are searching for the job.</li>
<li>	Define your career goals </li>
<li>	Learn how to design a powerful resume to attract employees</li>
<li>	5 major job seeking success principles</li>
<li>	How to target and get to your dream job
<li>	How to attend telephonic and direct interview</li>

<li>Introduction to different interview methodologies</li>
<li>How to handle psychometric and behavioral interview</li>
<li>Mock interviews and group discussions</li>
<li>Dos and don'ts of an interview</li>
<li>Eliminate fear factors associated with the interview</li>
<li>Prepare for all HR interview questions </li>
<li>Handle rejections and lead life with purpose</li>




                        </ul>
                         
  
                         
                         
                         
                         
                         
 <p> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=3" class="linkbtn "> Subscribe <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>