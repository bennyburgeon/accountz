<img src="<?php echo base_url(). 'uploads/'.$delete_file['photo'];?>" class="profile_img" style="width: 158px;"> 

