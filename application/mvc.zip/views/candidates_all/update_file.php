<img src="<?php echo base_url(). 'uploads/photos/'.$single_file['photo'];?>" class="profile_img" style="width: 158px;"> 

