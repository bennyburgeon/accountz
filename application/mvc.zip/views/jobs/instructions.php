
<div class="col-md-9">
<div class="profile_top">
<div class="profile_top_left">Instructions & Guidelines</div>
<!--<div class="profile_top_right">
<br>
<a href="javascript:alert('Write Code');">Delete this Job</a>	&nbsp;&nbsp;&nbsp;
</div>-->
<div style="clear:both;"></div>
</div>


<div style="border:solid;height:auto;">

        <table border="0" cellpadding="3" cellspacing="3" width="100%">
            <tbody>
                <tr>
                <td width="50" colspan="2" align="left" valign="top"><br><br></td>
                </tr>
                
                <tr>
                
                
                <td  valign="top"><div class="profile_box2">
            

               <strong> Visa : </strong><?php if(isset($row['visa']) && $row['visa']!='') echo $row['visa'] ?><br />
            
            	<strong>Medical : </strong><?php if(isset($row['medical']) && $row['medical']!='') echo $row['medical'] ?><br />
            
            	<strong>Docs Required :</strong> <?php if(isset($row['docs_required']) && $row['docs_required']!='') echo $row['docs_required'] ?><br />
               <strong> Visa Process :</strong> <?php if(isset($row['visa_process']) && $row['visa_process']!='') echo $row['visa_process'] ?><br />
          
           



</br>
 
    </div>
    </br>
   </td>
       		</tr>

    
            
            

            

            

   









      
  
















                        
</tbody>
</table>





</section>



</section>






</section>

<!------------------------ modal4 for Select on interview schedule------------------>


</section>




