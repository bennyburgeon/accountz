<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> CV Search & Preliminary Interviews  </h1>
<ol>                         
                      
<li>High quality candidate CVs at your fingertips </li>
<li>Target by skills, job title, salary, location, education and more </li>
<li>Preview a candidate's profile for free before viewing their CV </li>
<li>Download up to XXX CVs a day</li>
<li>Be the first to know about new candidates with daily email alerts</li>
<li>Shortlist candidates and share them with colleagues</li>

</ol>                         
                         
                         
                         
                         
 <p> <a href="<?php echo $this->config->base_url();?>index.php/contact/?service_type=11" class="linkbtn "> Subscribe <i class="fas fa-angle-double-right"></i>  </a></p>                        
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>