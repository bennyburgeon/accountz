<div class="blogbox service-bx">
      <div class="container"> 
         <div class="row">
                     <div class="col-md-12"> 
             <h1> About Us </h1>
                         
                         <h4>logis.ae – an exclusive job & career portal and services for the candidates and employers of Logistics and Supply Chain sectors in the United Arab Emirates, powered by Seekers.</h4>

                         
                         
 <p style="text-align: justify;">                       
Seekers Consultancy, based in Dubai, is one of the UAE’s leading HR, Outsourcing & Management consulting firms. We work with top executives to help them make better decisions and deliver the sustainable success they desire. We are passionate about achieving better results for our clients’ results that go beyond financial and are uniquely tailored, pragmatic, holistic, and enduring. 
</p>

 <p style="text-align: justify;">
Our consultancy services help the client to the meet market demands. We have a reputation for being passionate about consulting and innovation and providing enduring results for our clients. We continuously strive to enhance that reputation by maintaining the highest standards of service to our clients. 
</p>
 <p style="text-align: justify;">
logis.ae is an initiative by Seekers Consultancy exclusively to support the candidates and employers in Logistics and Supply Chain sectors in the UAE.
</p>
 <p style="text-align: justify;">
Candidates
<br>
For Candidates logis.ae offers an in-depth support process to assist you with making your next career step. his support process is further enhanced by our professional Careers Consultancy which can offer support including C.V. writing, CV distribution, webinars, and other services, market analysis and penetration, psychometric testing, and interview practices. We also assist the candidates in developing the career through continuous learning process.
</p>
 <p style="text-align: justify;">
Employers<br>

logis.ae offers professional recruitment and related services to companies in logistics and supply chain sectors in UAE, supporting them to get the right candidate. The service includes Learning & Development, Recruitment Process Outsourcing, Portal Subscription, Recruitment Software, Recruitment Training, Employer Branding, Job Posting and other Recruitment Assisting Services.
</p>
 <p style="text-align: justify;">
To know more about our services, please write to us : info@seekershr.com / info@logis.ae
</p>

 <p style="text-align: justify;">
Candidates looking for jobs, please forward your profile to jobs@logis.ae
</p>


                         
                         
 </div>
             
         
             
             
             
             
             
             
             
             
    
</div>   </div> </div>