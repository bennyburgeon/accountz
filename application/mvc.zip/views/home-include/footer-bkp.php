<footer>
  <div class="container-fluid top">
    <div class="row">
      <div class="col-sm-4 "></div>
      <div class="col-sm-5 "></div>
      <div class="col-sm-7 "></div>
    </div>
    
    
    <div class="col-sm-4 "></div>
      <div class="col-sm-4 text-center ">
      <h6><?php echo  $this->config->item('company_address');?></h6>
    </div>
      <div class="col-sm-4"></div> 
  </div>
  </div>
</footer>
</body>
</html>
