<div class="sidebar-area inner-pages">
<div class="side-btn"><img src="<?php echo base_url('assets/images/sidebar.png');?>"></div>
<div class="sidebar-2">
<div class="profile_box2 sides">
<h4>About:</h4>
<p>Lorem ipsum dolor sit amet diam nonummy nibh dolore.</p>
<h4>Contact:</h4>
<ul>
<li>Company Name</li>
<li>+97 254 2563 889</li>
<li>214 5454 878</li>
<li>4th Avenue, 2nd Street</li>
<li>somebody@test.com</li>
<li><a href="#">www.website.in</a></li>
<li class="social-p">
<a href="#"><img src="<?php echo base_url('assets/images/p_icon8.png');?>"></a>
<a href="#"><img src="<?php echo base_url('assets/images/p_icon9.png');?>"></a>
<a href="#"><img src="<?php echo base_url('assets/images/p_icon10.png');?>"></a>
<a href="#"><img src="<?php echo base_url('assets/images/p_icon11.png');?>"></a>
</li>
</ul>
</div>

</div>
</div>
<section class="bot-sep">
<div class="section-wrap">
<div class="row">
<div class="col-sm-12 pages">Futures / <span>Dashboard</span></div>
</div>
<div class="row">
<div class="col-sm-12">
<div class="tab-head mar-spec"><img src="<?php echo base_url('assets/images/head-icon-2.png');?>" alt=""/><h3>dashboard</h3></div>
<div class="table-tech specs">
<div class="right-btns">
<a href="form.html"><img src="<?php echo base_url('assets/images/new-order.png');?>"></a>
<a href="#"><img src="<?php echo base_url('assets/images/tools.png');?>"></a>
</div>
<table class="tool-table">
<tbody>
<tr>
<td><input class="form-control" id="inputdefault" type="text"></td>
<td><input class="form-control mars datepicker" type="text" placeholder="From"><input class="form-control marc datepicker" type="text" placeholder="To"></td>
<td><input class="form-control" id="inputdefault" type="text"></td>
<td><input class="form-control" id="inputdefault" type="text"></td>
<td><input class="form-control mars datepicker" type="text" placeholder="From"><input class="form-control marc datepicker" type="text" placeholder="To"></td>
<td><input class="form-control mars datepicker" type="text" placeholder="From"><input class="form-control marc datepicker" type="text" placeholder="To"></td>
<td>
<select class="form-control drops" id="sel1">
<option>Select</option>
<option>Select</option>
</select>
</td>
<td>
<a href="#" class="se-reset"><img src="<?php echo base_url('assets/images/search.png');?>"></a>
<a href="#"><img src="<?php echo base_url('assets/images/reset.png');?>"></a>
</td>
</tr>
</tbody>
</table>
<div class="sep-bar">
<div class="page">
<span>Page</span>
<a href="#"><img src="<?php echo base_url('assets/images/page-arrow-1.png');?>"></a>
<span>2 / 10</span>
<a href="#"><img src="<?php echo base_url('assets/images/page-arrow-2.png');?>"></a>
</div>
<div class="view-drop">
<span>View</span>
<select class="form-control drop" id="sel1">
<option>10</option>
<option>9</option>
</select>
<span>Records</span>
</div>
<div class="found"><span>Found total 178 records</span></div>
</div>
<div style="clear:both;"></div>
<table class="tool-table new">
<thead>
<tr>
<th><input name="" type="checkbox" value=""></th>
<th>Record</th>
<th>Date</th>
<th>Customer</th>
<th>Ship To</th>
<th>Price</th>
<th>Amount</th>
<th>Status</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>1</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png')?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>2</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>3</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>4</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>5</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>6</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>7</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>8</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>9</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
<tr>
<td><input name="" type="checkbox" value=""></td>
<td>10</td>
<td>12/09/2013</td>
<td>Jhon Doe</td>
<td>Jhon Doe</td>
<td>450.60$</td>
<td>6</td>
<td>Closed</td>
<td>
<a href="#" class="views" title="Follow"><img src="<?php echo base_url('assets/images/follows.png');?>"></a>
<a href="#" class="views" title="View"><img src="<?php echo base_url('assets/images/views.png');?>"></a>
<a href="#" class="views" title="Edit"><img src="<?php echo base_url('assets/images/edits.png');?>"></a>
<a href="#" class="views" title="Delete"><img src="<?php echo base_url('assets/images/deletes.png');?>"></a>
</td>
</tr>
</tbody>
</table>
<div class="sep-bar">
<div class="page">
<span>Page</span>
<a href="#"><img src="<?php echo base_url('assets/images/page-arrow-1.png');?>"></a>
<span>2 / 10</span>
<a href="#"><img src="<?php echo base_url('assets/images/page-arrow-2.png');?>"></a>
</div>
<div class="view-drop">
<span>View</span>
<select class="form-control drop" id="sel1">
<option>10</option>
<option>9</option>
</select>
<span>Records</span>
</div>
<div class="found"><span>Found total 178 records</span></div>
</div>
<div style="clear:both;"></div>
</div>
</div>
</div>
</div>
</section>

<!--scripts-->
<script src="<?php echo base_url('assets/js/jquery-1.11.3.min.js');?>"></script>
<script src="<?php echo base_url('assets/js/jquery.stickyfooter.js');?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('assets/js/animate_jquery.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/maps.googleapis.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/map.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.canvasjs.min.js');?>"></script>
<script src="<?php echo base_url('assets/js/jquery-ui.js');?>"></script>
  <script>
  $(function() {
    $( ".datepicker" ).datepicker();
  });
  </script>
<script src="<?php echo base_url('assets/js/custom.js');?>"></script>
<!--scripts-->